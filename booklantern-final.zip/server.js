
import express from 'express';
import path from 'path';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import NodeCache from 'node-cache';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 10000;
const buildId = '1759162248595';
const cache = new NodeCache({ stdTTL: 3600 });

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(morgan('dev'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());

// Static
app.use('/public', express.static(path.join(__dirname, 'public'), { maxAge: '7d' }));
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '7d' })); // for icons at root

// Global locals
app.use((req, res, next) => {
  res.locals.buildId = buildId;
  res.locals.isAuthenticated = false; // wire to your auth later
  res.locals.user = null;
  next();
});

// Fake data helpers
function card(provider, id, title, author, cover) {
  return { provider, id, title, author, cover };
}
function pgCover(id) { return `/proxy?url=${encodeURIComponent('https://www.gutenberg.org/cache/epub/'+id+'/pg'+id+'.cover.medium.jpg')}`; }

// Home
app.get('/', async (req, res) => {
  const trending = [
    card('pg','58988','Frankenstein','Mary Shelley', pgCover('58988')),
    card('pg','64176','Meditations','Marcus Aurelius', pgCover('64176')),
    card('pg','10471','A Princess of Mars','Edgar Rice Burroughs', pgCover('10471')),
    card('pg','26659','The Art of War','Sun Tzu', pgCover('26659')),
  ];
  const philosophy = [
    card('pg','7142','Thus Spake Zarathustra','F. Nietzsche', pgCover('7142')),
    card('pg','5827','Beyond Good and Evil','F. Nietzsche', pgCover('5827')),
    card('pg','6593','The Prince','Niccolò Machiavelli', pgCover('6593')),
    card('pg','47204','The Republic','Plato', pgCover('47204'))
  ];
  const history = [
    card('pg','42884','The Histories','Herodotus', pgCover('42884')),
    card('pg','14328','The Communist Manifesto','Marx & Engels', pgCover('14328')),
    card('pg','10643','The War of the Worlds','H. G. Wells', pgCover('10643')),
    card('pg','26659','The Art of War','Sun Tzu', pgCover('26659'))
  ];
  res.render('index', {
    pageTitle: 'Largest Online Hub of Free Books',
    pageDescription: 'Millions of free books from globally trusted libraries. One search, one clean reader.',
    trending, philosophy, history
  });
});

// Simple pages
app.get('/about', (req,res)=>res.render('about', { 
  pageTitle: 'About • BookLantern', 
  pageDescription: 'Connecting readers with the world’s largest collection of free books.' 
}));
app.get('/contact', (req,res)=>res.render('contact', { 
  pageTitle: 'Contact • BookLantern', 
  pageDescription: 'Contact BookLantern — we’d love to hear from you.' 
}));
app.get('/login', (req,res)=>res.render('login', { 
  pageTitle: 'Login – BookLantern', pageDescription: 'Sign in to BookLantern', referrer: req.get('referer') || '/' 
}));
app.get('/register', (req,res)=>res.render('register', { 
  pageTitle: 'Create Account – BookLantern', pageDescription: 'Create a free account on BookLantern', referrer: req.get('referer') || '/' 
}));
app.get('/dashboard', (req,res)=>res.render('dashboard', { 
  pageTitle: 'Your Library – BookLantern', pageDescription: 'Your saved books and notes', 
  saves: [], notes: [], csrfToken: 'noop' 
}));
app.get('/watch', (req,res)=>res.render('watch', {
  pageTitle: 'Watch – BookLantern',
  pageDescription: 'Author talks, lectures and book videos',
  videos: []
}));

// Read
app.get('/read/:provider/:id', (req,res)=>{
  const { provider, id } = req.params;
  res.render('read', { 
    pageTitle: 'Read – BookLantern', pageDescription: 'Read in a clean, fast reader',
    provider, id, referrer: req.get('referer') || '/' 
  });
});

// Minimal API for /read
app.get('/api/book', async (req,res)=>{
  const provider = req.query.provider || 'pg';
  const id = req.query.id || '58988';
  if (provider === 'pg') {
    // Placeholder content
    return res.json({
      type: 'text',
      title: 'Sample Book',
      author: 'Anonymous',
      content: '<h2>Sample</h2><p>This is a placeholder. Wire real sources later.</p>'
    });
  }
  res.json({ type: 'text', title: 'Unknown', content: 'Unsupported provider.' });
});

// Simple proxy (cache + CORS)
app.get('/proxy', async (req,res)=>{
  const url = req.query.url;
  if (!url) return res.status(400).send('Missing url');
  try {
    const cached = cache.get(url);
    if (cached) {
      res.set(cached.headers);
      return res.send(cached.body);
    }
    const ctrl = new AbortController();
    const to = setTimeout(()=>ctrl.abort(), 8000);
    const r = await fetch(url, { signal: ctrl.signal });
    clearTimeout(to);
    const buf = Buffer.from(await r.arrayBuffer());
    const headers = {
      'content-type': r.headers.get('content-type') || 'application/octet-stream',
      'cache-control': 'public, max-age=86400'
    };
    cache.set(url, { body: buf, headers }, 3600);
    res.set(headers).send(buf);
  } catch(e) {
    res.status(500).send('Proxy error');
  }
});

// Service worker + offline
app.get('/sw.js', (req,res)=>res.sendFile(path.join(__dirname,'public','sw.js')));
app.get('/public/offline.html', (req,res)=>res.sendFile(path.join(__dirname,'public','offline.html')));

// 404/Errors
app.use((req,res)=>res.status(404).render('404', { pageTitle: 'Page Not Found – BookLantern', pageDescription: 'Not found' }));
app.use((err, req, res, next)=>{
  console.error('🔥 Unhandled error:', err);
  res.status(500).render('error', { pageTitle: 'Error – BookLantern', pageDescription: 'Server error' });
});

app.listen(PORT, ()=>{
  console.log(`BookLantern listening on :${PORT}`);
});
